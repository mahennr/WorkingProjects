package com.institution.studentmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.institution.studentmanagement.entity.StudentInfo;
import com.institution.studentmanagement.service.StudentService;

// @RestController
@Controller
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentService studentService;

	public StudentController(StudentService studentService) {
		super();
		this.studentService = studentService;
	}

	// handler method to handle list of students and return mode and view
	@GetMapping("/students")
	public String listStudents(Model model) {
		model.addAttribute("students", studentService.getAllStudents());
		return "students";
	}

	// create student object to hold student form data
	@GetMapping("/students/new")
	public String createStudentForm(Model model) {
		StudentInfo student = new StudentInfo();
		model.addAttribute("student", student);
		return "create_student";
	}
	
	// GET student by id
	@GetMapping("/students/edit/{id}")
	public String editStudentForm(@PathVariable Integer id, Model model) {
		model.addAttribute("student", studentService.getStudentById(id));
		return "edit_student";
	}
	
	@PostMapping("/students")
	public String saveStudent(@ModelAttribute("student") StudentInfo student) {
		studentService.saveStudent(student);
		return "redirect:/students";
	}
	
	@PostMapping("/students/{id}")
	public String updateStudent(@PathVariable Integer id, @ModelAttribute("student") StudentInfo student, Model model) {

		// set student from database by id
		StudentInfo existingStudent = studentService.getStudentById(id);
		existingStudent.setRollNo(id);

		existingStudent.setFirstName(student.getFirstName());
		existingStudent.setLastName(student.getLastName());

		// save updated student object
		studentService.updateStudent(existingStudent);
		return "redirect:/students";
	}

	// GET student by id
	@GetMapping("/students/{id}")
	public String deleteStudent(@PathVariable Integer id) {
		studentService.deleteStudentById(id);
		return "redirect:/students";
	}
}
