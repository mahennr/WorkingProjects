package com.institution.studentmanagement.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="Institution" )
@Data
public class Institution {
	
	@Id
	int institutionId;
	
	@OneToMany(mappedBy="pesit", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private List<CourseInfo> courses;
	
	@Column(name = "institution_name")
	String institutionName;

}
