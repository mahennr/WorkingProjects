package com.institution.studentmanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.institution.studentmanagement.entity.StudentInfo;
import com.institution.studentmanagement.repository.StudentRepo;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepo studentRepository;
	
	private StudentService studentService;

	public StudentServiceImpl(StudentRepo studentRepository) {
		super();
		this.studentRepository = studentRepository;
	}

	@Override
	public List<StudentInfo> getAllStudents() {
		return studentRepository.findAll();
	}

	@Override
	public StudentInfo saveStudent(StudentInfo student) {
		return studentRepository.save(student);
	}

	@Override
	public StudentInfo getStudentById(Integer id) {
		return studentRepository.getById(id);
	}

	@Override
	public StudentInfo updateStudent(StudentInfo student) {
		//Optional<StudentInfo> studtOption = studentRepository.findById(student.getRollNo());
		StudentInfo existingStudent= new existingStudent();
		existingStudent.setFirstName(existingStudent.getFirstName());
		existingStudent.setLastName(existingStudent.getLastName());
		existingStudent.setLocation(existingStudent.getLocation());
		existingStudent.setAge(existingStudent.getAge());
		existingStudent.setLocation(existingStudent.getLocation());
		existingStudent.setContactNo(existingStudent.getContactNo());	
		
		//studentService.updateStudent(existingStudent);
		return existingStudent;
		
		// StudentRepo.save(student);
		  // public Employee updateEmployee(Employee employee){
		  //   employee.setName("Updated name");
	      // employeeRepository.save(employee);
		  //  return employee;
	}

	@Override
	public void deleteStudentById(Integer id) {
		studentRepository.deleteById(id); // deleteById(id);
	}
}
