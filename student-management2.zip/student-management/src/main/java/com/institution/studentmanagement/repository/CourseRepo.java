package com.institution.studentmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.institution.studentmanagement.entity.CourseInfo;

public interface CourseRepo extends JpaRepository <CourseInfo,Integer> {
	
}
