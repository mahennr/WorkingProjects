package com.institution.studentmanagement.entity;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "course")
@Data
public class CourseInfo {

	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	int courseId;

	// Mapping many courses to the Institution table
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "course", nullable = false)
	private Institution pesit;

	@Column(name = "course_name")
	String courseName;

	@OneToMany(mappedBy = "students", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<StudentInfo> student = new ArrayList<StudentInfo>();

	public CourseInfo() {
	}

}
