package com.institution.studentmanagement.service;

import java.util.List;

import com.institution.studentmanagement.entity.StudentInfo;

public interface StudentService {
		
	List<StudentInfo> getAllStudents();
	
	StudentInfo saveStudent(StudentInfo student);
	
	StudentInfo getStudentById(Integer id);
	
	void deleteStudentById(Integer id);

	StudentInfo updateStudent(StudentInfo student);

}
