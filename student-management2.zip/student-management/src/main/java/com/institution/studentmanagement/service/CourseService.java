package com.institution.studentmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.institution.studentmanagement.entity.CourseInfo;
import com.institution.studentmanagement.repository.CourseRepo;

@Service
public class CourseService 
{
	@Autowired
	private CourseRepo courseRepository;
	
	public List<CourseInfo> findAll() {
		return courseRepository.findAll();
	}
	
	public CourseInfo findById(int id) {
		return courseRepository.findById(id).get();
	}
	
	@Transactional
	public CourseInfo save(CourseInfo course) {
		return courseRepository.save(course);
	}
}
