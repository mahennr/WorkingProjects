package com.institution.studentmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.institution.studentmanagement.entity.CourseInfo;
import com.institution.studentmanagement.service.CourseService;

@Controller
@RequestMapping("/courses")
public class CourseController {
	
	@Autowired
	private CourseService courseService;
	
	@GetMapping("")
	public String findAll(Model model)
	{
		List<CourseInfo> courses = CourseInfo.findAll();
		model.addAttribute("courses", courses);
		return "course-list";
	}
	
	@GetMapping("/{id}")
	public String findById(@PathVariable("id") int id, Model model) 
	{
		CourseInfo course = CourseService.findById(id);
		model.addAttribute("course", course);
		return "course";
	}
	
	@GetMapping("/add")
	public String add(Model model)
	{
		CourseInfo theCourse = new CourseInfo();
		model.addAttribute("theCourse", theCourse);
		return "course-form";
	}
	
	@PostMapping("/save")
	public String save(@ModelAttribute("theCourse") CourseInfo theCourse)
	{
		CourseService.save(theCourse);
		return "redirect:/courses";
	}
	
}
